<?php
$timezone = 'Asia/jakarta';
date_default_timezone_set($timezone);
